public class Avion {
    public final String placa;
    public boolean enAire;
    public static final int TRIPULACION_MIN = 2;
    private int puntaje;
    public Posicion ubicacion;

    public Avion(String placa) {
        this.placa = placa;
    }
}