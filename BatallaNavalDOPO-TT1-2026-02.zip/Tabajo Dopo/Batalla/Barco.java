public class Barco {
    public final int numero;
    public static final int TRIPULACION_MIN = 4;
    private int puntaje;
    public Posicion ubicacion;

    public Barco(int numero) {
        this.numero = numero;
    }
}
