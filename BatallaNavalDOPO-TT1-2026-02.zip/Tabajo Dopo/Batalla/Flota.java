import java.util.ArrayList;

public class Flota {
    public final int codigoFlota;
    String nombre;
    ArrayList<Barco> barcos;
    ArrayList<Avion> aviones;
    ArrayList<PortaAviones> portaAviones;
    ArrayList<Marino> marinos;

    public Flota(int codigoFlota, String nombre) {
        this.codigoFlota   = codigoFlota;
        this.nombre        = nombre;
        this.barcos        = new ArrayList<Barco>();
        this.aviones       = new ArrayList<Avion>();
        this.portaAviones  = new ArrayList<PortaAviones>();
        this.marinos       = new ArrayList<Marino>();
    }

    /**
     * Consulta el numero de maquinas que tiene la flota
     * @return numero de maquinas de la flota
     */
    public int numeroMaquinas() {
        return barcos.size() + aviones.size() + portaAviones.size();
    }


    /**
     * Consulta si cuenta con suficientes marinos para conducir sus máquinas.
     * Un portaaviones requiere 5 marinos; un barco, 4; y un avión 2.
     * @return si hay suficientes marinos
     */
    public boolean suficientesMarinos() {
        int necesarios = (portaAviones.size() * PortaAviones.TRIPULACION_MIN)
                       + (barcos.size()       * Barco.TRIPULACION_MIN)
                       + (aviones.size()      * Avion.TRIPULACION_MIN);
        return marinos.size() >= necesarios;
    }


    /**
     * Consulta el número de flotas que tienen su mismo nombre
     * @return numero de flotas con el mismo nombre
     */
    public int alias(Tablero tablero) {
        int count = 0;
        for (int i = 0; i < tablero.flotas.size(); i++) {
            Flota f = tablero.flotas.get(i);
            if (f != this && f.nombre.equals(this.nombre)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Consulta la disponibilidad total de los portaaviones
     * @return numero de aviones adicionales que podrían cargarse
     */
    public int disponibilidadEnPortaaviones() {
        int disponibilidad = 0;
        for (int i = 0; i < portaAviones.size(); i++) {
            PortaAviones pa = portaAviones.get(i);
            disponibilidad += pa.capacidad - pa.aviones.size();
        }
        return disponibilidad;
    }

    /**
     * Mueve todos los barcos la distancia definida, si es posible.
     * @param deltaLongitud avance en longitud
     * @param deltaLatitud  avance en latitud
     */
    public void muevase(int deltaLongitud, int deltaLatitud) {
        for (int i = 0; i < barcos.size(); i++) {
            Barco b = barcos.get(i);
            int nuevaLong = b.ubicacion.longitud + deltaLongitud;
            int nuevaLat  = b.ubicacion.latitud  + deltaLatitud;
            if (nuevaLong >= Tablero.LONG_MIN && nuevaLong <= Tablero.LONG_MAX &&
                nuevaLat  >= Tablero.LAT_MIN  && nuevaLat  <= Tablero.LAT_MAX) {
                b.ubicacion.longitud = nuevaLong;
                b.ubicacion.latitud  = nuevaLat;
            }
        }
    }

    /**
     * Consulta las máquinas que pueden afectarse por una explosión en agua.
     * Los aviones en el aire NO se afectan.
     * @param longitud longitud de la explosión
     * @param latitud  latitud de la explosión
     * @return lista de máquinas en esa ubicación que serán destruidas
     */
    public ArrayList<Object> seranDestruidas(int longitud, int latitud) {
        ArrayList<Object> destruidas = new ArrayList<Object>();

        for (int i = 0; i < barcos.size(); i++) {
            Barco b = barcos.get(i);
            if (b.ubicacion.longitud == longitud &&
                b.ubicacion.latitud  == latitud) {
                destruidas.add(b);
            }
        }

        for (int i = 0; i < portaAviones.size(); i++) {
            PortaAviones pa = portaAviones.get(i);
            if (pa.ubicacion.longitud == longitud &&
                pa.ubicacion.latitud  == latitud) {
                destruidas.add(pa);
            }
            for (int j = 0; j < pa.aviones.size(); j++) {
                Avion a = pa.aviones.get(j);
                if (!a.enAire &&
                    a.ubicacion.longitud == longitud &&
                    a.ubicacion.latitud  == latitud) {
                    destruidas.add(a);
                }
            }
        }

        for (int i = 0; i < aviones.size(); i++) {
            Avion a = aviones.get(i);
            if (!a.enAire &&
                a.ubicacion.longitud == longitud &&
                a.ubicacion.latitud  == latitud) {
                destruidas.add(a);
            }
        }

        return destruidas;
    }

    /**
     * Consulta la placa de los aviones enemigos que están en el aire
     * @param tablero tablero del juego que contiene todas las flotas
     * @return la placa de los aviones enemigos que están en el aire
     */
    public ArrayList<String> enAire(Tablero tablero) {
        ArrayList<String> placas = new ArrayList<String>();

        for (int i = 0; i < tablero.flotas.size(); i++) {
            Flota f = tablero.flotas.get(i);
            if (f == this) continue;

            for (int j = 0; j < f.aviones.size(); j++) {
                Avion a = f.aviones.get(j);
                if (a.enAire) {
                    placas.add(a.placa);
                }
            }

            for (int j = 0; j < f.portaAviones.size(); j++) {
                PortaAviones pa = f.portaAviones.get(j);
                for (int k = 0; k < pa.aviones.size(); k++) {
                    Avion a = pa.aviones.get(k);
                    if (a.enAire) {
                        placas.add(a.placa);
                    }
                }
            }
        }

        return placas;
    }

    /**
     * Consulta si puede confundir sus aviones con aviones enemigos
     * considerando las placas
     * @param tablero tablero del juego que contiene todas las flotas
     * @return si hay problema en aire
     */
    public boolean problemaEnAire(Tablero tablero) {
        ArrayList<String> enemigos = enAire(tablero);

        for (int i = 0; i < aviones.size(); i++) {
            Avion a = aviones.get(i);
            if (a.enAire && enemigos.contains(a.placa)) {
                return true;
            }
        }

        for (int i = 0; i < portaAviones.size(); i++) {
            PortaAviones pa = portaAviones.get(i);
            for (int j = 0; j < pa.aviones.size(); j++) {
                Avion a = pa.aviones.get(j);
                if (a.enAire && enemigos.contains(a.placa)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Verifica si la ubicación para un ataque en agua es adecuada.
     * Destruye elementos enemigos sin ocasionar bajas propias.
     * Los aviones volando no se afectan.
     * @param longitud longitud de la explosión
     * @param latitud  latitud de la explosión
     * @param tablero  tablero del juego que contiene todas las flotas
     * @return true si destruye enemigos y no afecta máquinas propias
     */
    public boolean esBuenAtaque(int longitud, int latitud, Tablero tablero) {
        if (!seranDestruidas(longitud, latitud).isEmpty()) {
            return false;
        }

        for (int i = 0; i < tablero.flotas.size(); i++) {
            Flota f = tablero.flotas.get(i);
            if (f == this) continue;
            if (!f.seranDestruidas(longitud, latitud).isEmpty()) {
                return true;
            }
        }

        return false;
    }
}
