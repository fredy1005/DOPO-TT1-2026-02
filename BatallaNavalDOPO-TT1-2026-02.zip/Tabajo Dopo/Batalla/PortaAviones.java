import java.util.ArrayList;

public class PortaAviones {
    public final int numero;
    public int capacidad;
    public static final int TRIPULACION_MIN = 5;
    private int puntaje;
    public Posicion ubicacion;
    public ArrayList<Avion> aviones;

    public PortaAviones(int numero, int capacidad) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.aviones = new ArrayList<Avion>();
    }
}