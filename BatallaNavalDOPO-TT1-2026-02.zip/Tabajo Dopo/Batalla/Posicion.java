
public class Posicion {
    public int longitud;
    public int latitud;

    public Posicion(int longitud, int latitud) {
        this.longitud = longitud;
        this.latitud  = latitud;
    }
}