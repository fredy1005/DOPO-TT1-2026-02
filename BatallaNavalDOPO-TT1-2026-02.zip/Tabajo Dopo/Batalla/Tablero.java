import java.util.ArrayList;

public class Tablero {
    public static final int LONG_MAX =  100;
    public static final int LONG_MIN = -100;
    public static final int LAT_MAX  =  100;
    public static final int LAT_MIN  = -100;
    public ArrayList<Flota> flotas;  

    public Tablero() {
        this.flotas = new ArrayList<Flota>();
    }
}